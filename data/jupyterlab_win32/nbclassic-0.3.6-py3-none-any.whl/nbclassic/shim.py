from notebook_shim.shim import *


NBClassicConfigShimMixin = NotebookConfigShimMixin
